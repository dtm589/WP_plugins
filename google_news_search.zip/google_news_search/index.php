<?php
// In place for security, prevents typing in the URL directly to the plug in